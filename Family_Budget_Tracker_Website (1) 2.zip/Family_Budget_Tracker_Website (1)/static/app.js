document.addEventListener("DOMContentLoaded", () => {
  const palette = ["#168657","#4d91e9","#f6ad45","#a37bdc","#9caaa2"];
  function makeChart(id, data, type="doughnut") {
    const canvas = document.getElementById(id);
    if (!canvas || typeof Chart === "undefined") return;
    const labels = Object.keys(data || {});
    const values = labels.map(k => Number(data[k] || 0));
    new Chart(canvas, {
      type, data: { labels, datasets: [{ data: values, backgroundColor: palette,
        borderWidth: type === "doughnut" ? 2 : 0, borderRadius: type === "bar" ? 6 : 0,
        hoverOffset: 7 }] },
      options: { responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:false} },
        scales: type === "bar" ? {y:{beginAtZero:true,grid:{color:"#edf1ee"}},x:{grid:{display:false}}} : {} }
    });
  }
  makeChart("categoryChart", window.budgetData || {});
  makeChart("reportChart", window.reportData || {}, "bar");
});
