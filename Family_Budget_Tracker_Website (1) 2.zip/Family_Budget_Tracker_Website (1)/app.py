from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3, os
from datetime import date
from functools import wraps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "budget.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
CATEGORIES = ["Groceries", "Transport", "Utilities", "Health", "Other"]

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'Member'
        );
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            purchase_date TEXT NOT NULL,
            amount REAL NOT NULL CHECK(amount > 0),
            category TEXT NOT NULL,
            note TEXT DEFAULT '',
            receipt_file TEXT DEFAULT '',
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        CREATE TABLE IF NOT EXISTS budgets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT UNIQUE NOT NULL,
            monthly_limit REAL NOT NULL
        );
        """)
        if con.execute("SELECT COUNT(*) FROM budgets").fetchone()[0] == 0:
            con.executemany("INSERT INTO budgets(category, monthly_limit) VALUES(?,?)",
                            [("Groceries",40000),("Transport",20000),("Utilities",25000),("Health",15000),("Other",20000)])
        if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            con.execute("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)",
                        ("Yersultan","demo@family.kz",generate_password_hash("family123"),"Admin"))
            uid = con.execute("SELECT id FROM users WHERE email='demo@family.kz'").fetchone()["id"]
            samples = [
                (uid,"2026-11-02",18450,"Groceries","Weekly shopping",""),
                (uid,"2026-11-04",8500,"Transport","Taxi and bus",""),
                (uid,"2026-11-06",12000,"Utilities","Electricity bill",""),
                (uid,"2026-11-08",7200,"Health","Pharmacy",""),
                (uid,"2026-11-09",15730,"Groceries","Market","")
            ]
            con.executemany("INSERT INTO expenses(user_id,purchase_date,amount,category,note,receipt_file) VALUES(?,?,?,?,?,?)", samples)

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_globals():
    return {"categories": CATEGORIES, "current_user": session.get("name")}

@app.route("/")
def index():
    return redirect(url_for("dashboard") if session.get("user_id") else url_for("login"))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name","").strip()
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        if not name or not email or len(password) < 6:
            flash("Заполните все поля. Пароль должен быть не короче 6 символов.", "error")
        else:
            try:
                with db() as con:
                    con.execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                                (name,email,generate_password_hash(password)))
                flash("Аккаунт создан. Теперь войдите.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Этот email уже зарегистрирован.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email","").strip().lower()
        password = request.form.get("password","")
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.update(user_id=user["id"], name=user["name"], role=user["role"])
            return redirect(url_for("dashboard"))
        flash("Неверный email или пароль.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    month = date.today().strftime("%Y-%m")
    with db() as con:
        rows = con.execute("SELECT * FROM expenses WHERE user_id=? AND substr(purchase_date,1,7)=? ORDER BY purchase_date DESC",
                           (session["user_id"],month)).fetchall()
        budgets = con.execute("SELECT * FROM budgets ORDER BY category").fetchall()
    total = sum(r["amount"] for r in rows)
    by_cat = {c:sum(r["amount"] for r in rows if r["category"]==c) for c in CATEGORIES}
    limits = {b["category"]:b["monthly_limit"] for b in budgets}
    alerts = [c for c in CATEGORIES if limits.get(c,0) and by_cat[c] >= limits[c]*.9]
    return render_template("dashboard.html", rows=rows, total=total, by_cat=by_cat,
                           limits=limits, alerts=alerts, income=320000, savings=50000)

@app.route("/expenses", methods=["GET","POST"])
@login_required
def expenses():
    if request.method == "POST":
        try:
            amount = float(request.form.get("amount","0"))
            pdate = request.form.get("purchase_date","")
            category = request.form.get("category","")
            note = request.form.get("note","").strip()
            if amount <= 0 or category not in CATEGORIES or not pdate or pdate > date.today().isoformat():
                raise ValueError()
            with db() as con:
                duplicate = con.execute("""SELECT id FROM expenses WHERE user_id=? AND purchase_date=? AND amount=? AND category=?""",
                                        (session["user_id"],pdate,amount,category)).fetchone()
                if duplicate and request.form.get("confirm_duplicate") != "yes":
                    flash("Похожая покупка уже есть. Проверьте список перед повторным сохранением.", "error")
                    return redirect(url_for("expenses"))
                con.execute("INSERT INTO expenses(user_id,purchase_date,amount,category,note) VALUES(?,?,?,?,?)",
                            (session["user_id"],pdate,amount,category,note))
            flash("Расход добавлен.", "success")
            return redirect(url_for("expenses"))
        except (ValueError, TypeError):
            flash("Проверьте сумму, дату и категорию. Дата не может быть в будущем.", "error")
    with db() as con:
        rows = con.execute("SELECT * FROM expenses WHERE user_id=? ORDER BY purchase_date DESC",
                           (session["user_id"],)).fetchall()
    return render_template("expenses.html", rows=rows, today=date.today().isoformat())

@app.route("/scan", methods=["GET","POST"])
@login_required
def scan():
    if request.method == "POST":
        file = request.files.get("receipt")
        if file and file.filename:
            safe = secure_filename(file.filename)
            filename = f"{session['user_id']}_{safe}"
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
            flash("Чек загружен. Автоматическое распознавание OCR можно подключить отдельно; внесите сумму и категорию вручную.", "success")
            return redirect(url_for("expenses"))
        flash("Выберите изображение чека.", "error")
    return render_template("scan.html")

@app.route("/reports")
@login_required
def reports():
    with db() as con:
        rows = con.execute("""SELECT category, SUM(amount) total FROM expenses
                              WHERE user_id=? AND substr(purchase_date,1,7)=? GROUP BY category""",
                           (session["user_id"],date.today().strftime("%Y-%m"))).fetchall()
    totals = {c:0 for c in CATEGORIES}
    for r in rows: totals[r["category"]] = r["total"]
    return render_template("reports.html", totals=totals, grand=sum(totals.values()))

@app.route("/family")
@login_required
def family():
    with db() as con:
        members = con.execute("SELECT id,name,email,role FROM users ORDER BY id").fetchall()
    return render_template("family.html", members=members)

@app.route("/budget", methods=["GET","POST"])
@login_required
def budget():
    if request.method == "POST":
        with db() as con:
            for c in CATEGORIES:
                try: value = max(0,float(request.form.get(c,"0")))
                except ValueError: value = 0
                con.execute("UPDATE budgets SET monthly_limit=? WHERE category=?", (value,c))
        flash("Лимиты бюджета обновлены.", "success")
        return redirect(url_for("budget"))
    with db() as con:
        limits = con.execute("SELECT * FROM budgets ORDER BY category").fetchall()
    return render_template("budget.html", limits=limits)

@app.route("/about")
@login_required
def about():
    return render_template("about.html")

@app.route("/settings")
@login_required
def settings():
    return render_template("settings.html")

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
